import ResultsPage from "./components/results-page/ResultsPage"
import SearchPage from "./components/search-page/SearchPage"
import './components/style/style.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { createContext, useState } from 'react'

export const AppContext = createContext({});

function App() {
  const [seacrhResult, setSearchResult] = useState({});

  return (
    <AppContext.Provider value={{ seacrhResult, setSearchResult }}>
      <BrowserRouter>
        <Routes>
          <Route path="/" Component={SearchPage} />
          <Route path="/results" Component={ResultsPage} />
        </Routes>
      </BrowserRouter>
    </AppContext.Provider>
  )
}

export default App
